import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Start from '@/pages/Start'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello,
      children: [
      ]

    },
       {                
          path: '/profile',
          name: 'Profile',
          component: require('../pages/Profile.vue'),
        },
           {                
          path: '/home',
          name: 'home',
          component: require('../pages/Home.vue'),
        },
    {
      path: '/start',
      name: 'Start',
      component: Start
    },
    {
      path: '/login',
      name: 'Login',
      component: require('../pages/Login.vue'),
    },
  ]
})
