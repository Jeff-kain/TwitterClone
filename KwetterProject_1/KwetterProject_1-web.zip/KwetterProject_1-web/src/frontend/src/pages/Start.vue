<style scoped>
.pv-top-card-section__edit-photo {
    background-color: transparent;
}
.profile-photo-edit {
    position: relative;
    background-color: #e6e9ec;
    display: flex;
    align-items: left;
    border-radius:20px;
}
#imageUpload
{
    display: none;
}

#profileImage
{
    cursor: pointer;
    height:40%;
    width: 40%;
    border-radius:20px;
    
}
.trends {
   position: relative;
    background-color: #e6e9ec;
    display: flex;
    flex-direction: column;
    align-items: left;
    box-sizing: border-box;
    border-radius:20px;
    margin-top:2%;
    height:500px;
}
.kweets {
   position: relative;
    background-color: #e6e9ec;
    border-radius:20px;
    height:100px;
    align-items:left;
    
}
.timeline {
    margin-top:2%;

}
.centerContent {
    margin-left: 25%;
    margin-right: 30%;
    width:35%;
  
}
.mainContent {
    margin-left: 20%;
}
.Profile-and-trends {
    margin-left: 1%;
    padding-right: 1%;
    float: left;
    width:20%;
}
.firstContent {
    margin-right: 1%;
}
.timelineMessage {
    position: relative;
    background-color: #e6e9ec;
    align-items: left;
    border-radius:20px;
    height:100px;
    margin-top:25px;
}
</style>
<template>
  <div class="mainContent" >
  <div class="firstContent">
   <div class="Profile-and-trends">
      <div id="ember5808" class="pv-top-card-section__edit-photo profile-photo-edit">
  <img id="profileImage" src="../images/Donald_pepe.png"/>
<input id="imageUpload" type="file" 
       name="profile_photo" placeholder="Photo" required="" capture>
  </div>  
  <div id="trends" class="trends pv-top-card-section__edit-photo" >
  TODO trends
  </div>
  </div>
  <div class="centerContent">
    <div id="kweets" class="kweets" >
  <textarea rows="6" cols="40">
At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
</textarea>
  </div>
        <div id="timeline" class="timeline">
         <div class="timelineMessage">
      TODO hello @Jeff 52 min geleden
      </div>
           <div class="timelineMessage">
      TODO hello @Bob 53 min geleden
      </div>
      </div>
  </div>
  </div>
  </div>
</template>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
export default {
  name: 'app'
}
</script>
